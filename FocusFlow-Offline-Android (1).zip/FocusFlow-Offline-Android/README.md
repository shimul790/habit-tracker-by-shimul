# FocusFlow Offline Android

Tasks + Habits + Reminders + Time tracker. The UI is one HTML file inside the APK (`app/src/main/assets/index.html`). Data stays in WebView localStorage. No server.

## Phone theke GitHub e upload kore APK (Android Studio lagbe na)

1. GitHub-e login kore **public** repository banan. Name: `FocusFlow-Offline`.
2. এই ZIP extract korun (ZArchiver).
3. Repository **root**-এ এই ফাইল/ফোল্ডারগুলো আপলোড করুন (একটা extra folder-এর ভিতরে না):
   - `settings.gradle`
   - `build.gradle`
   - `gradle.properties`
   - `.gitignore`
   - `README.md`
   - `app/` (পুরো ফোল্ডার)
   - `.github/workflows/build-apk.yml`
4. **Actions** ট্যাব খুলুন। প্রথমবার Actions enable করতে বললে enable করুন।
5. **Build FocusFlow APK** workflow → **Run workflow**.
   Push করলেও `main`/`master` ব্রাঞ্চে অটো বিল্ড শুরু হবে।
6. সবুজ টিক হলে সেই run-এর **Artifacts** থেকে `FocusFlow-debug-APK` ডাউনলোড করুন।
7. ZIP খুলে `app-debug.apk` ইনস্টল করুন। Unknown apps allow করতে হতে পারে।

বিল্ড হয় GitHub-এর ক্লাউডে, ফোনে নয়।

## Android Studio

1. Open → এই ফোল্ডার সিলেক্ট করুন (যেখানে `settings.gradle` আছে)।
2. SDK Platform 35 লাগলে ইনস্টল হতে দিন।
3. Build → Build APK(s).
4. Output: `app/build/outputs/apk/debug/app-debug.apk`

## Package

- Application id: `com.focusflow.offline`
- minSdk 23, target/compile 35
- App name: FocusFlow

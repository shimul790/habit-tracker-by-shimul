FocusFlow — Offline Personal Productivity App

Files:
- index.html: complete single-file app (HTML, CSS, JavaScript embedded)

Run:
1. Extract this ZIP.
2. Open index.html in a mobile browser, or copy it to:
   app/src/main/assets/index.html
   for an Android WebView using file:///android_asset/index.html

Data is stored locally in the browser/WebView localStorage. Export a JSON backup from Settings before clearing app/browser data.
No network connection, CDN, framework, build step, notification API, or service worker is required.
